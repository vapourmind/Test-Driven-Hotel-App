﻿using System.Collections.Generic;
using TestDrivenHotelApp.DAL.Models;

namespace TestDrivenHotelApp.BLL.Interfaces
{
    public interface IRoomService
    {
        List<RoomModel> RetrieveRooms();
        List<RoomModel> ResetFiltersToShowAllRooms();
    }
}
