﻿using TestDrivenHotelApp.DAL.Models;
using System.Collections.Generic;
using System.Linq;

namespace TestDrivenHotelApp.BLL
{
    public class RoomManager
    {
        public List<RoomModel> FilterRoomsByRoomType(List<RoomModel> rooms, RoomType roomType)
        {
            return rooms.Where(r => r.Type == roomType).ToList();
        }

        public List<RoomModel> FilterRoomsByAC(List<RoomModel> rooms, bool hasAC)
        {
            return rooms.Where(r => r.HasAC == hasAC).ToList();
        }

        public List<RoomModel> FilterRoomsByTV(List<RoomModel> rooms, bool hasTV)
        {
            return rooms.Where(r => r.HasTV == hasTV).ToList();
        }

        public List<RoomModel> FilterRoomsByMiniBar(List<RoomModel> rooms, bool hasMiniBar)
        {
            return rooms.Where(r => r.HasMiniBar == hasMiniBar).ToList();
        }

        public List<RoomModel> FilterRoomsByWiFi(List<RoomModel> rooms, bool hasWiFi)
        {
            return rooms.Where(r => r.HasWiFi == hasWiFi).ToList();
        }
        public List<RoomModel> FilterRoomsByAvailability(List<RoomModel> rooms, bool isAvailable)
        {
            return rooms.Where(r => r.IsAvailable == isAvailable).ToList();
        }

        public List<RoomModel> FilterRoomsByMultipleCriteria(List<RoomModel> rooms, Func<RoomModel, bool> predicate)
        {
            return rooms.Where(predicate).ToList();
        }

        public List<RoomModel> SortRoomsByAscendingPrice(List<RoomModel> rooms)
        {
            return rooms.OrderBy(r => r.PricePerDay).ToList();
        }

        public List<RoomModel> SortRoomsByDescendingPrice(List<RoomModel> rooms)
        {
            return rooms.OrderByDescending(r => r.PricePerDay).ToList();
        }

        public List<RoomModel> FilterRoomsByPriceRange(List<RoomModel> rooms, int minPrice, int maxPrice)
        {
            return rooms.Where(r => r.PricePerDay >= minPrice && r.PricePerDay <= maxPrice).ToList();
        }

        public List<RoomModel> SortRoomsByRoomNumber(List<RoomModel> rooms)
        {
            return rooms.OrderBy(r => r.Id).ToList();
        }
        public List<RoomModel> ResetFiltersToShowAllRooms(List<RoomModel> rooms)
        {
            return rooms.ToList();
        }
    }
}