﻿using System.Collections.Generic;
using TestDrivenHotelApp.BLL.Interfaces;
using TestDrivenHotelApp.DAL;
using TestDrivenHotelApp.DAL.Interfaces;
using TestDrivenHotelApp.DAL.Models;

namespace TestDrivenHotelApp.BLL.Services
{
    public class RoomService : IRoomService
    {
        private readonly IRoomRepository _roomRepository;

        public RoomService(IRoomRepository roomRepository)
        {
            _roomRepository = roomRepository ?? throw new ArgumentNullException(nameof(roomRepository));
        }

        public List<RoomModel> RetrieveRooms()
        {
            try
            {
                var rooms = _roomRepository.GetRooms();
                return rooms.OrderBy(r => r.Id).ToList();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to retrieve rooms", ex);
            }
        }

        public List<RoomModel> ResetFiltersToShowAllRooms()
        {
            return _roomRepository.GetRooms();
        }
    }
}
