﻿using System.Collections.Generic;
using TestDrivenHotelApp.DAL.Interfaces;
using TestDrivenHotelApp.DAL.Models;

namespace TestDrivenHotelApp.DAL
{
    public class HotelRepo : IRoomRepository
    {
        public static List<RoomModel> Rooms { get; set; } = new()
        {
            new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
            new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false),
            new RoomModel(3, "Room 3", 50000, true, false, false, true, RoomType.SmallRoom, true),
            new RoomModel(4, "Room 4", 300000, true, true, false, true, RoomType.LargeRoom, true),
            new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false)
        };

        public List<RoomModel> GetRooms()
        {
            try
            {
                return Rooms;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return new List<RoomModel>();
            }
        }
    }
}
