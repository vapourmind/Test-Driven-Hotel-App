﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDrivenHotelApp.DAL.Models
{
    public class RoomModel
    {
        public int Id { get; set; } 
        public string Name { get; set; }
        public int PricePerDay { get; set; }
        public bool HasWiFi { get; set; }
        public bool HasTV { get; set; }
        public bool HasMiniBar { get; set; }
        public bool HasAC { get; set; }
        public RoomType Type { get; set; }
        public bool IsAvailable { get; set; }

        public RoomModel()
        {
        }

        public RoomModel(int id, string name, int pricePerDay, bool hasWiFi, bool hasTV, bool hasMiniBar, bool hasAC, RoomType type, bool isAvailable)
        {
            Id = id;
            Name = name;
            PricePerDay = pricePerDay;
            HasWiFi = hasWiFi;
            HasTV = hasTV;
            HasMiniBar = hasMiniBar;
            HasAC = hasAC;
            Type = type;
            IsAvailable = isAvailable;
        }
    }
}
