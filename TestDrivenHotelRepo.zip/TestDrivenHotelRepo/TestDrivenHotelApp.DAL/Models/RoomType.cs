﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestDrivenHotelApp.DAL.Models
{
    public enum RoomType
    {
        SmallRoom,
        MediumRoom,
        LargeRoom,
        DeluxeRoom,
        PenthouseSuite
    }
}

