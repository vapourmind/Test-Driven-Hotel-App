﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestDrivenHotelApp.DAL.Models;

namespace TestDrivenHotelApp.DAL.Interfaces
{
    public interface IRoomRepository
    {
        List<RoomModel> GetRooms();
    }
}