using TestDrivenHotelApp.BLL;
using TestDrivenHotelApp.Pages;
using TestDrivenHotelApp.DAL;
using TestDrivenHotelApp.DAL.Models;
using TestDrivenHotelApp.BLL.Services;
using TestDrivenHotelApp.DAL.Interfaces;
using FluentAssertions;
using Moq;

namespace TestDrivenHotelApp.Tests
{
    public class RoomUnitTests
    {

        private readonly RoomManager roomManager = new RoomManager();

        [Fact]
        public void FilterRoomsByRoomType_ReturnsFilteredListOfChosenRoomType()
        {
            //Given
            var rooms = new List<RoomModel>
            {
                new RoomModel(1, "Room 1", 10000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 50000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(3, "Room 3", 30000, true, false, false, true, RoomType.LargeRoom, true)
            };

            //When
            var filteredRooms = roomManager.FilterRoomsByRoomType(rooms, RoomType.MediumRoom);

            //Then
            filteredRooms.Should().NotBeNull();
            filteredRooms.Should().HaveCount(1);
            filteredRooms.Should().Contain(r => r.Name == "Room 1");
        }

        [Fact]
        public void FilterRoomsByAC_ReturnsFilteredListOfRoomsWithAC()
        {
            //Given
            var rooms = new List<RoomModel>
            {
                new RoomModel(1, "Room 1", 10000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 50000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(3, "Room 3", 30000, true, false, false, true, RoomType.LargeRoom, true),
                new RoomModel(4, "Room 4", 30000, true, false, false, false, RoomType.SmallRoom, true),
                new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false)
            };

            //When
            var filteredRooms = roomManager.FilterRoomsByAC(rooms, true);

            //Then
            filteredRooms.Should().NotBeNull();
            filteredRooms.Should().HaveCount(4);
            filteredRooms.Should().Contain(r => r.Name == "Room 1");
            filteredRooms.Should().Contain(r => r.Name == "Room 2");
            filteredRooms.Should().Contain(r => r.Name == "Room 3");
            filteredRooms.Should().Contain(r => r.Name == "Room 5");
        }

        [Fact]
        public void FilterRoomsByTV_ReturnsFilteredListOfRoomsWithTV()
        {
            //Given
            var rooms = new List<RoomModel>
            {
                new RoomModel(1, "Room 1", 10000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 50000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(3, "Room 3", 30000, true, false, false, true, RoomType.LargeRoom, true),
                new RoomModel(4, "Room 4", 30000, true, false, false, false, RoomType.SmallRoom, true),
                new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false)
            };

            //When
            var filteredRooms = roomManager.FilterRoomsByTV(rooms, true);

            //Then
            filteredRooms.Should().NotBeNull();
            filteredRooms.Should().HaveCount(3);
            filteredRooms.Should().Contain(r => r.Name == "Room 1");
            filteredRooms.Should().Contain(r => r.Name == "Room 2");
            filteredRooms.Should().Contain(r => r.Name == "Room 5");
        }

        [Fact]
        public void FilterRoomsByMiniBar_ReturnsFilteredListOfRoomsWithMiniBar()
        {
            //Given
            var rooms = new List<RoomModel>
            {
                new RoomModel(1, "Room 1", 10000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 50000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(3, "Room 3", 30000, true, false, false, true, RoomType.LargeRoom, true),
                new RoomModel(4, "Room 4", 30000, true, false, false, false, RoomType.SmallRoom, true),
                new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false)
            };
            
            //When
            var filteredRooms = roomManager.FilterRoomsByMiniBar(rooms, true);

            //Then
            filteredRooms.Should().NotBeNull();
            filteredRooms.Should().HaveCount(2);
            filteredRooms.Should().Contain(r => r.Name == "Room 2");
            filteredRooms.Should().Contain(r => r.Name == "Room 5");
        }

        [Fact]
        public void FilterRoomsByWiFi_ReturnsFilteredListOfRoomsWithWiFi()
        {
            // Given
            var rooms = new List<RoomModel>
        {
            new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
            new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false),
            new RoomModel(3, "Room 3", 300000, true, false, false, true, RoomType.LargeRoom, true),
            new RoomModel(4, "Room 4", 30000, false, false, false, false, RoomType.SmallRoom, true),
            new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false)
        };

            // When
            var filteredRooms = roomManager.FilterRoomsByWiFi(rooms, true);

            // Then
            filteredRooms.Should().NotBeNull();
            filteredRooms.Should().HaveCount(4);
            filteredRooms.Should().Contain(r => r.Name == "Room 1");
            filteredRooms.Should().Contain(r => r.Name == "Room 2");
            filteredRooms.Should().Contain(r => r.Name == "Room 3");
            filteredRooms.Should().Contain(r => r.Name == "Room 5");
        }

        [Fact]
        public void SortRoomsByPriceAscending_ReturnsListOfRoomsSortedByAscendingPrice()
        {
            //Given
            var rooms = new List<RoomModel>
            {
                new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(3, "Room 3", 300000, true, false, false, true, RoomType.LargeRoom, true),
                new RoomModel(4, "Room 4", 30000, true, false, false, false, RoomType.SmallRoom, true),
                new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false)
            };

            //When
            var sortedRooms = roomManager.SortRoomsByAscendingPrice(rooms);

            //Then
            sortedRooms.Should().NotBeNull();
            sortedRooms.Should().HaveCount(5);
            sortedRooms[0].PricePerDay.Should().Be(30000);
            sortedRooms[1].PricePerDay.Should().Be(100000);
            sortedRooms[2].PricePerDay.Should().Be(300000);
            sortedRooms[3].PricePerDay.Should().Be(500000);
            sortedRooms[4].PricePerDay.Should().Be(900000);
        }

        [Fact]
        public void SortRoomsByPriceDescending_ReturnsSortedListOfRoomsByDescendingPrice()
        {
            //Given
            var rooms = new List<RoomModel>
            {
                new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(3, "Room 3", 300000, true, false, false, true, RoomType.LargeRoom, true),
                new RoomModel(4, "Room 4", 30000, true, false, false, false, RoomType.SmallRoom, true),
                new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false)
            };

            //When
            var sortedRooms = roomManager.SortRoomsByDescendingPrice(rooms);

            //Then
            sortedRooms.Should().NotBeNull();
            sortedRooms.Should().HaveCount(5);
            sortedRooms[0].PricePerDay.Should().Be(900000);
            sortedRooms[1].PricePerDay.Should().Be(500000);
            sortedRooms[2].PricePerDay.Should().Be(300000);
            sortedRooms[3].PricePerDay.Should().Be(100000);
            sortedRooms[4].PricePerDay.Should().Be(30000);

        }

        [Fact]
        public void FilterRoomsByPriceRange_ReturnsFilteredListOfRoomsInRange()
        {
            //Given
            var rooms = new List<RoomModel>
            {
                new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(3, "Room 3", 300000, true, false, false, true, RoomType.LargeRoom, true),
                new RoomModel(4, "Room 4", 30000, true, false, false, false, RoomType.SmallRoom, true),
                new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false)
            };

            //When
            var filteredRooms = roomManager.FilterRoomsByPriceRange(rooms, 200000, 600000);

            //Then
            filteredRooms.Should().NotBeNull();
            filteredRooms.Should().HaveCount(2);
            filteredRooms[0].PricePerDay.Should().Be(500000);
            filteredRooms[1].PricePerDay.Should().Be(300000);
        }

        [Fact]
        public void FilterRoomsByAvailability_ReturnsFilteredListOfRoomsByAvailability()
        {
            //Given
            var rooms = new List<RoomModel>
            {
                new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(3, "Room 3", 300000, true, false, false, true, RoomType.LargeRoom, true),
                new RoomModel(4, "Room 4", 30000, true, false, false, false, RoomType.SmallRoom, true),
                new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false)
            };

            //When
            var filteredRooms = roomManager.FilterRoomsByAvailability(rooms, true);

            //Then
            filteredRooms.Should().NotBeNull();
            filteredRooms.Should().HaveCount(3);
            filteredRooms.Should().Contain(r => r.Name == "Room 1");
            filteredRooms.Should().Contain(r => r.Name == "Room 3");
            filteredRooms.Should().Contain(r => r.Name == "Room 4");
        }

        [Fact]
        public void FilterRoomsByMultipleCriteria_ReturnsFilteredListOfRoomsByMultipleCriteria()
        {
            //Given
            var rooms = new List<RoomModel>
            {
            new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
            new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false),
            new RoomModel(3, "Room 3", 300000, true, false, false, true, RoomType.LargeRoom, true),
            new RoomModel(4, "Room 4", 30000, true, false, false, false, RoomType.SmallRoom, true),
            new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false)
            };

            //When
            var filteredRooms = roomManager.FilterRoomsByMultipleCriteria(rooms,
                r => r.HasAC && r.HasTV);

            //Then
            filteredRooms.Should().NotBeNull();
            filteredRooms.Should().HaveCount(3);
            filteredRooms[0].Name.Should().Be("Room 1");
            filteredRooms[1].Name.Should().Be("Room 2");
            filteredRooms[2].Name.Should().Be("Room 5");
        }


        [Fact]
        public void ResetFilters_ReturnsAllRooms()
        {
            //Given
            var rooms = new List<RoomModel>
            {
                new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(3, "Room 3", 300000, true, false, false, true, RoomType.LargeRoom, true),
                new RoomModel(4, "Room 4", 30000, true, false, false, false, RoomType.SmallRoom, true),
                new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false)
            };

            //When
            var filteredRooms = roomManager.ResetFiltersToShowAllRooms(rooms);

            //Then
            filteredRooms.Should().NotBeNull();
            filteredRooms.Should().HaveCount(5);
        }

        [Fact]
        public void FilterButtonClick_ReturnsEvent()
        {
            //Given
            var mockRoomRepository = new Mock<IRoomRepository>();
            mockRoomRepository.Setup(repo => repo.GetRooms()).Returns(new List<RoomModel>
            {
                new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(3, "Room 3", 30000, true, false, false, true, RoomType.LargeRoom, true)
            });

            var roomService = new RoomService(mockRoomRepository.Object);
            var roomManager = new RoomManager();

            var pageModel = new IndexModel(roomService, roomManager);

            pageModel.Rooms = roomService.RetrieveRooms();

            //When
            pageModel.OnPostFilterButtonClick(filterByTV: true);

            //Then
            pageModel.FilterButtonClicked.Should().BeTrue();
            pageModel.FilteredRooms.Should().NotBeNull();
            pageModel.FilteredRooms.Count.Should().Be(2);
            pageModel.FilteredRooms.Should().Contain(r => r.Name == "Room 1");
            pageModel.FilteredRooms.Should().Contain(r => r.Name == "Room 2");
        }


        [Fact]
        public void OnSearchButtonClick_ShouldFilterRoomsBasedOnSearchCriteria()
        {
            //Given
            var mockRoomRepository = new Mock<IRoomRepository>();
            mockRoomRepository.Setup(repo => repo.GetRooms()).Returns(new List<RoomModel>
            {
                new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(3, "Room 3", 30000, true, false, false, true, RoomType.LargeRoom, true)
            });

            var roomService = new RoomService(mockRoomRepository.Object);
            var roomManager = new RoomManager();

            var pageModel = new IndexModel(roomService, roomManager);

            pageModel.Rooms = roomService.RetrieveRooms();
            pageModel.SearchCriteria = "Room 1";

            //When
            pageModel.OnPostSearchButtonClick();

            //Then
            pageModel.FilteredRooms.Should().NotBeNull();
            pageModel.FilteredRooms.Should().HaveCount(1);
            pageModel.FilteredRooms[0].Name.Should().Be("Room 1");
        }

        [Fact]
        public void RetrieveRooms_WhenErrorOccurs_ShouldHandleError()
        {
            //Given
            var hotelRepoMock = new Mock<IRoomRepository>();
            hotelRepoMock.Setup(repo => repo.GetRooms()).Throws(new Exception("Failed to retrieve rooms"));

            var roomService = new RoomService(hotelRepoMock.Object);

            //When
            Action action = () => roomService.RetrieveRooms();

            //Then
            action.Should().Throw<Exception>().WithMessage("Failed to retrieve rooms");
        }

        [Fact]
        public void GetRooms_ShouldRetrieveAndMapRooms()
        {
            //Given
            var hotelRepo = new HotelRepo();

            //When
            var rooms = hotelRepo.GetRooms();

            //Then
            rooms.Should().NotBeNull();
            rooms.Should().NotBeEmpty();

            foreach (var room in rooms)
            {
                room.Id.Should().BeGreaterThan(0);
                room.Name.Should().NotBeNullOrEmpty();
            }
        }

        [Fact]
        public void GetRooms_WhenExceptionOccurs_ShouldHandleError()
        {
            //Given
            var roomRepositoryMock = new Mock<IRoomRepository>();
            roomRepositoryMock.Setup(repo => repo.GetRooms()).Throws(new Exception("Failed to retrieve rooms"));

            var roomService = new RoomService(roomRepositoryMock.Object);

            //When
            Action action = () => roomService.RetrieveRooms();

            //Then
            action.Should().Throw<Exception>().WithMessage("Failed to retrieve rooms");
        }


        [Fact]
        public void RetrieveRooms_ReturnsRoomsSortedByDefaultOrder()
        {
            //Given
            var mockRepo = new Mock<IRoomRepository>();
            mockRepo.Setup(repo => repo.GetRooms()).Returns(new List<RoomModel>
            {
                new RoomModel(3, "Room 3", 30000, true, false, false, true, RoomType.SmallRoom, true),
                new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false)
            });

            var roomService = new RoomService(mockRepo.Object);

            //When
            var rooms = roomService.RetrieveRooms();

            //Then
            rooms.Should().NotBeNull();
            rooms.Should().BeInAscendingOrder(r => r.Id);
        }


        [Fact]
        public void SortRoomsByRoomNumber_ReturnsSortedListOfRoomsByRoomNumber()
        {
            //Given
            var rooms = new List<RoomModel>
            {
                new RoomModel(2, "Room 2", 500000, true, true, true, true, RoomType.DeluxeRoom, false),
                new RoomModel(4, "Room 4", 30000, true, false, false, false, RoomType.SmallRoom, true),
                new RoomModel(1, "Room 1", 100000, true, true, false, true, RoomType.MediumRoom, true),
                new RoomModel(5, "Room 5", 900000, true, true, true, true, RoomType.PenthouseSuite, false),
                new RoomModel(3, "Room 3", 300000, true, false, false, true, RoomType.LargeRoom, true)
            };

            //When
            var sortedRooms = roomManager.SortRoomsByRoomNumber(rooms);

            //Then
            sortedRooms.Should().NotBeNull(); 
            sortedRooms.Should().HaveCount(5);
            sortedRooms[0].Name.Should().Be("Room 1");
            sortedRooms[1].Name.Should().Be("Room 2");
            sortedRooms[2].Name.Should().Be("Room 3");
            sortedRooms[3].Name.Should().Be("Room 4");
            sortedRooms[4].Name.Should().Be("Room 5");
        }

    }
}