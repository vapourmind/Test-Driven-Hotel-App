﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using TestDrivenHotelApp.BLL;
using TestDrivenHotelApp.BLL.Services;
using TestDrivenHotelApp.DAL.Models;
using Microsoft.AspNetCore.Mvc;

namespace TestDrivenHotelApp.Pages
{
    public class IndexModel : PageModel
    {
        public List<RoomModel>? Rooms { get; set; } = new List<RoomModel>();
        public bool SearchButtonClicked { get; set; }
        public bool FilterButtonClicked { get; set; }
        public List<RoomModel> FilteredRooms { get; set; } = new List<RoomModel>();
        [BindProperty]
        public string SearchCriteria { get; set; }
        [BindProperty]
        public int MinPrice { get; set; }
        [BindProperty]
        public int MaxPrice { get; set; }
        public bool FilterByTV { get; set; }
        public bool FilterByWiFi { get; set; }
        public bool FilterByAC { get; set; }
        public bool FilterByMiniBar { get; set; }
        public bool FilterByAvailability { get; set; }
        private readonly RoomService _roomService;
        private readonly RoomManager _roomManager;

        public IndexModel(RoomService roomService, RoomManager roomManager)
        {
            _roomService = roomService;
            _roomManager = roomManager;
        }

        public void OnGet()
        {
            Rooms = _roomService.RetrieveRooms();
            if (FilteredRooms == null || !FilteredRooms.Any())
            {
                FilteredRooms = new List<RoomModel>(Rooms);
            }
        }

        public void OnPostSearchButtonClick()
        {

            SearchButtonClicked = true;
            Rooms = _roomService.RetrieveRooms();

            if (SearchCriteria == null)
            {
                SearchCriteria = string.Empty;
            }

            if (!string.IsNullOrEmpty(SearchCriteria))
            {
                FilteredRooms = Rooms.Where(r => r.Name.Contains(SearchCriteria, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            else
            {
                FilteredRooms = new List<RoomModel>(Rooms);
            }
        }

        public void OnPostFilterButtonClick(bool filterByTV = false, bool filterByWiFi = false, bool filterByAC = false, bool filterByMiniBar = false, bool filterByAvailability = false)
        {
            FilterButtonClicked = true;
            Func<RoomModel, bool> predicate = null;
            Rooms = _roomService.RetrieveRooms();
            var filtered = Rooms.AsQueryable();

            if (filterByTV)
            {
                predicate = r => r.HasTV;
            }
            if (filterByWiFi)
            {
                if (predicate == null)
                    predicate = r => r.HasWiFi;
                else
                    predicate = And(predicate, r => r.HasWiFi);
            }
            if (filterByAC)
            {
                if (predicate == null)
                    predicate = r => r.HasAC;
                else
                    predicate = And(predicate, r => r.HasAC);
            }
            if (filterByMiniBar)
            {
                if (predicate == null)
                    predicate = r => r.HasMiniBar;
                else
                    predicate = And(predicate, r => r.HasMiniBar);
            }
            if (filterByAvailability)
            {
                if (predicate == null)
                    predicate = r => r.IsAvailable;
                else
                    predicate = And(predicate, r => r.IsAvailable);
            }

            if (predicate != null)
            {
                FilteredRooms = _roomManager.FilterRoomsByMultipleCriteria(Rooms, predicate);
            }
            else
            {
                FilteredRooms = new List<RoomModel>(Rooms);
            }
        }

        private Func<T, bool> And<T>(Func<T, bool> first, Func<T, bool> second)
        {
            return arg => first(arg) && second(arg);
        }

        public void OnGetSortByAscendingPrice()
        {
            if (FilteredRooms == null || !FilteredRooms.Any())
            {
                Rooms = _roomService.RetrieveRooms();
                FilteredRooms = new List<RoomModel>(Rooms);
            }
            FilteredRooms = _roomManager.SortRoomsByAscendingPrice(FilteredRooms);
        }

        public void OnGetSortByDescendingPrice()
        {
            if (FilteredRooms == null || !FilteredRooms.Any())
            {
                Rooms = _roomService.RetrieveRooms();
                FilteredRooms = new List<RoomModel>(Rooms);
            }
            FilteredRooms = _roomManager.SortRoomsByDescendingPrice(FilteredRooms);
        }

        public void OnPostFilterByPriceRange()
        {
           if (FilteredRooms == null || !FilteredRooms.Any())
            {
                Rooms = _roomService.RetrieveRooms();
                FilteredRooms = new List<RoomModel>(Rooms);
            }
            FilteredRooms = _roomManager.FilterRoomsByPriceRange(Rooms, MinPrice, MaxPrice);
        }

        public void OnPostResetFiltersButtonClick()
        {
            Rooms = _roomService.RetrieveRooms();
            FilteredRooms = new List<RoomModel>(Rooms);
        }
    }
}
